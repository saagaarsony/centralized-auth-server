const { verifyAccessToken } = require('../utils/jwtUtils');
const db = require('../db/database');

/**
 * Middleware to authenticate requests using Access Token
 */
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

    if (!token) {
        return res.status(401).json({ message: 'Access Token Required' });
    }

    const user = verifyAccessToken(token);

    if (!user) {
        return res.status(403).json({ message: 'Invalid or Expired Access Token' });
    }

    // Attach user to request object
    req.user = user;

    // Optional: Check if session is explicitly invalidated in DB (if enforcing strict session control even for access tokens)
    // For standard JWT flow, we usually just trust the signature until expiry.
    // But for high security, you might want to check the DB if the corresponding session is still active.

    next();
};

module.exports = authenticateToken;
