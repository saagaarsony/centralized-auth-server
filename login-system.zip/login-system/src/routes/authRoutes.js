const express = require('express');
const router = express.Router();
const users = require('../../users.json');
const db = require('../db/database');
const { generateAccessToken, generateRefreshToken, verifyRefreshToken, verifyAccessToken } = require('../utils/jwtUtils');

// Helper to find user by email
const findUser = (email) => users.find(u => u.email === email);

/**
 * POST /auth/login
 * Input: email, password, module_name
 */
router.post('/login', (req, res) => {
    const { email, password, module_name } = req.body;

    // 1. Validate User Credentials
    const user = findUser(email);
    if (!user || user.password !== password) {
        return res.status(401).json({ message: 'Invalid credentials' });
    }

    // 2. Generate Tokens
    const accessToken = generateAccessToken(user);
    const refreshToken = generateRefreshToken(user);

    // 3. Save Session to DB
    const stmt = db.prepare(`
    INSERT INTO sessions (user_id, email, role, module_name, refresh_token, ip_address, user_agent)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);

    const ip = req.ip;
    const userAgent = req.headers['user-agent'];

    stmt.run(user.id, user.email, user.role, module_name, refreshToken, ip, userAgent, function (err) {
        if (err) {
            return res.status(500).json({ message: 'Error creating session', error: err.message });
        }

        // Return Tokens
        res.json({
            accessToken,
            refreshToken,
            user: {
                id: user.id,
                email: user.email,
                role: user.role
            }
        });
    });
    stmt.finalize();
});

/**
 * POST /auth/refresh
 * Input: refresh_token
 */
router.post('/refresh', (req, res) => {
    const { refresh_token } = req.body;

    if (!refresh_token) {
        return res.status(401).json({ message: 'Refresh Token Required' });
    }

    // 1. Verify Refresh Token Signature
    const userPayload = verifyRefreshToken(refresh_token);
    if (!userPayload) {
        return res.status(403).json({ message: 'Invalid Refresh Token' });
    }

    // 2. Check if Refresh Token matches active session in DB
    db.get(
        `SELECT * FROM sessions WHERE refresh_token = ? AND is_active = 1`,
        [refresh_token],
        (err, session) => {
            if (err) return res.status(500).json({ error: err.message });
            if (!session) return res.status(403).json({ message: 'Session invalid or expired' });

            // 3. Issue new Access Token
            // We can use the payload from the token, or query users.json again for fresh data
            // For simplicity/consistency, let's use the payload but ensure we strip exp/iat
            const newAccessToken = generateAccessToken({
                id: userPayload.userId,
                email: userPayload.email,
                role: userPayload.role
            });

            // Optionally rotate refresh token here for better security

            res.json({ accessToken: newAccessToken });
        }
    );
});

/**
 * POST /auth/logout
 * Input: refresh_token
 */
router.post('/logout', (req, res) => {
    const { refresh_token } = req.body;

    if (!refresh_token) {
        // If no token provided, we can't really "logout" a specific session, unless we use the access token user ID
        // But the requirement says Input: refresh_token
        return res.status(400).json({ message: 'Refresh Token Required for Logout' });
    }

    // Mark session as inactive
    const logoutTime = new Date().toISOString();

    db.run(
        `UPDATE sessions SET is_active = 0, logout_time = ? WHERE refresh_token = ?`,
        [logoutTime, refresh_token],
        function (err) {
            if (err) return res.status(500).json({ error: err.message });

            if (this.changes === 0) {
                return res.status(404).json({ message: 'Session not found or already logged out' });
            }

            res.json({ message: 'Logged out successfully' });
        }
    );
});

/**
 * GET /auth/verify
 * Header: Authorization: Bearer <access_token>
 */
router.get('/verify', (req, res) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) return res.status(401).json({ valid: false, message: 'No token provided' });

    const user = verifyAccessToken(token);

    if (!user) {
        return res.status(403).json({ valid: false, message: 'Invalid or expired token' });
    }

    // Optionally check if session is still active in DB for this user if needed
    // For strict SSO:
    // We might want to check if *any* active session exists for this user, or if we track specific access tokens (we don't)
    // For now, consistent with "Stateless Access Token" pattern, we trust the token if it's valid.

    res.json({
        valid: true,
        user: user
    });
});

module.exports = router;
